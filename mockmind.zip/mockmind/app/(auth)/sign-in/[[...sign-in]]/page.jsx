import { SignIn } from "@clerk/nextjs";
import Image from "next/image"; // Use Next.js Image for optimization

export default function Page() {
  return (
    <div className="flex h-screen">
      {/* Left Side - Image & Text */}
      <div className="hidden md:flex flex-col justify-center items-center w-1/2 bg-gray-100 p-8 h-full">
        <Image
          src="/Logo.png" // Replace with your actual image path (Place in 'public' folder)
          alt="MockMind"
          width={1000}
          height={1000}
          className="rounded-lg shadow-lg h-full object-cover"
        />
        <h2 className="text-3xl font-bold text-gray-700 mt-6">Welcome to Mock Mind</h2>
        <p className="text-gray-500 mt-2 text-center">
          Enhance your interview preparation with Mock Mind.
        </p>
      </div>

      {/* Right Side - Clerk Sign-In Form */}
      <div className="flex justify-center items-center w-full md:w-1/2">
        <SignIn />
      </div>
    </div>
  );
}
