import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center h-screen gap-6">

      <h1 className="text-4xl font-bold">Welcome to Mock Interview App 🎯</h1>

      <p className="text-gray-500">
        Practice interviews powered by AI
      </p>

      {/* ✅ Dashboard Button */}
      <Link href="/dashboard">
        <Button className="text-lg px-6 py-3">
          Go to Dashboard
        </Button>
      </Link>

    </div>
  );
}