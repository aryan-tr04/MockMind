import { Lightbulb, Volume2 } from 'lucide-react'
import React from 'react'

function QuestionSection({ mockInterviewQuestion = [], activeQuestionIndex }) {

    const textToSpeech = (text) => {
        if (typeof window !== "undefined" && 'speechSynthesis' in window) {
            const speech = new SpeechSynthesisUtterance(text);
            window.speechSynthesis.speak(speech);
        } else {
            alert('Sorry, Your Browser Does not Support Text To Speech');
        }
    }

    return (
        <div className='p-5 border rounded-lg my-10'>

            {/* Question Numbers */}
            <div className='grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5'>
                {mockInterviewQuestion?.map((question, index) => (
                    <h2
                        key={index}   // ✅ FIXED (IMPORTANT)
                        className={`p-2 bg-secondary rounded-full text-xs md:text-sm text-center cursor-pointer 
                        ${activeQuestionIndex === index ? 'bg-blue-700 text-primary' : ''}`}
                    >
                        Question #{index + 1}
                    </h2>
                ))}
            </div>

            {/* Current Question */}
            <h2 className='my-5 text-md md:text-lg'>
                {mockInterviewQuestion?.[activeQuestionIndex]?.question || "Loading question..."}
            </h2>

            {/* Text to Speech */}
            <Volume2
                className='cursor-pointer'
                onClick={() =>
                    textToSpeech(mockInterviewQuestion?.[activeQuestionIndex]?.question)
                }
            />

            {/* Note Section */}
            <div className='border rounded-lg p-5 bg-blue-100 mt-20'>
                <h2 className='flex gap-2 items-center text-primary'>
                    <Lightbulb />
                    <strong>Note:</strong>
                </h2>
                <h2 className='text-sm text-primary my-2'>
                    {process.env.NEXT_PUBLIC_QUESTION_NOTE}
                </h2>
            </div>

        </div>
    )
}

export default QuestionSection