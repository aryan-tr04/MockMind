"use client"

import { db } from '@/utils/db'
import { UserAnswer } from '@/utils/schema'
import { eq } from 'drizzle-orm'
import React, { useEffect, useState } from 'react'
import {
    Collapsible,
    CollapsibleContent,
    CollapsibleTrigger,
} from "@/components/ui/collapsible"
import { ChevronsUpDown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useRouter, useParams } from 'next/navigation'

function Feedback() {
    const [feedbackList, setFeedbackList] = useState([])
    const router = useRouter()

    // ✅ FIX: useParams instead of params
    const { interviewId } = useParams()

    useEffect(() => {
        const fetchFeedback = async () => {
            try {
                const result = await db.select()
                    .from(UserAnswer)
                    .where(eq(UserAnswer.mockIdRef, interviewId))
                    .orderBy(UserAnswer.id)

                console.log("Feedback Data:", result)
                setFeedbackList(result)

            } catch (error) {
                console.error("Error fetching feedback:", error)
            }
        }

        if (interviewId) {
            fetchFeedback()
        }

    }, [interviewId])

    return (
        <div className='p-10'>

            {feedbackList.length === 0 ? (
                <h2 className='font-bold text-xl text-gray-500'>
                    No Interview Feedback Record Found
                </h2>
            ) : (
                <>
                    <h2 className='text-3xl font-bold text-green-500'>
                        Congratulations!
                    </h2>

                    <h2 className='font-bold text-2xl'>
                        Here is your interview feedback
                    </h2>

                    <h2 className='text-primary text-lg my-3'>
                        Your overall interview rating: <strong>7/10</strong>
                    </h2>

                    <h2 className='text-sm text-gray-600'>
                        Find below the interview questions with correct answers,
                        your answers, and feedback for improvement.
                    </h2>

                    {feedbackList.map((item, index) => (
                        <Collapsible key={index} className='mt-7'>

                            <CollapsibleTrigger className='p-2 flex justify-between bg-secondary rounded-lg my-2 text-left gap-7 w-full'>
                                {item.question}
                                <ChevronsUpDown className='h-4 w-5'/>
                            </CollapsibleTrigger>

                            <CollapsibleContent>
                                <div className='flex flex-col gap-2'>

                                    <h2 className='text-red-500 p-2 border rounded-lg'>
                                        <strong>Rating: </strong>{item.rating}
                                    </h2>

                                    <h2 className='bg-red-100 text-sm p-2 border rounded-lg text-red-900'>
                                        <strong>Your Answer: </strong>{item.userAns}
                                    </h2>

                                    <h2 className='bg-green-100 text-sm p-2 border rounded-lg text-green-900'>
                                        <strong>Correct Answer: </strong>{item.correctAns}
                                    </h2>

                                    <h2 className='bg-blue-100 text-sm p-2 border rounded-lg text-primary'>
                                        <strong>Feedback: </strong>{item.feedback}
                                    </h2>

                                </div>
                            </CollapsibleContent>

                        </Collapsible>
                    ))}
                </>
            )}

            <Button
                className="mt-5"
                onClick={() => router.replace('/dashboard')}
            >
                Go Home
            </Button>

        </div>
    )
}

export default Feedback