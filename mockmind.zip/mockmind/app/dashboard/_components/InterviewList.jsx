"use client"
import { db } from '@/utils/db';
import { MockInterview } from '@/utils/schema';
import { useUser } from '@clerk/nextjs'
import { desc, eq } from 'drizzle-orm';
import React, { useEffect, useState } from 'react'
import InterviewItemCard from './InterviewItemCard';

function InterviewList() {
    const { user } = useUser();  // ✅ Destructure correctly
    const [interviewList, setInterviewList] = useState([]);

    useEffect(() => {
        if (user) GetInterviewList();  // ✅ Ensure `user` exists before calling
    }, [user]);

    const GetInterviewList = async () => {
            const result = await db.select()  // ✅ Fixed: `db.select()` should be a function
                .from(MockInterview)
                .where(eq(MockInterview.createdBy, user?.primaryEmailAddress?.emailAddress))
                .orderBy(desc(MockInterview.id));

            console.log(result);
            setInterviewList(result);  // ✅ Update state safely
    };

    return (
        <div>
            <h2 className='font-medium text-xl'>Previous Mock Interviews</h2>

            <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 my-3'>
                {interviewList&&interviewList.map((interview,index)=>(
                    <InterviewItemCard
                     interview={interview} key={index} />
                ))}
            </div>
        </div>
    );
}

export default InterviewList;
