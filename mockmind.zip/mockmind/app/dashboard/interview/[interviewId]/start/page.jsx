"use client"

import { db } from '@/utils/db';
import { MockInterview } from '@/utils/schema';
import { eq } from 'drizzle-orm';
import React, { useEffect, useState } from 'react'
import QuestionSection from './_components/QuestionSection';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import dynamic from 'next/dynamic';

// ✅ Disable SSR for mic (fix window error)
const RecordAnswerSection = dynamic(
    () => import('./_components/RecordAnswerSection'),
    { ssr: false }
);

function StartInterview() {

    const { interviewId } = useParams();

    const [interviewData, setInterviewData] = useState(null);

    // ✅ Always initialize as array
    const [mockInterviewQuestion, setMockInterviewQuestion] = useState([]);

    const [activeQuestionIndex, setActiveQuestionIndex] = useState(0);

    useEffect(() => {
        if (interviewId) {
            GetInterviewDetails();
        }
    }, [interviewId]);

    /* Fetch interview details */
    const GetInterviewDetails = async () => {
        try {
            const result = await db.select()
                .from(MockInterview)
                .where(eq(MockInterview.mockId, interviewId));

            if (!result || result.length === 0) {
                console.log("No interview found");
                return;
            }

            let jsonMockResp;

            // ✅ SAFE PARSE (IMPORTANT FIX)
            try {
                jsonMockResp = JSON.parse(result[0]?.jsonMockResp || "[]");
            } catch (err) {
                console.log("JSON parse error:", err);
                jsonMockResp = [];
            }

            // ✅ Ensure always array
            if (!Array.isArray(jsonMockResp)) {
                jsonMockResp = [jsonMockResp];
            }

            console.log("Questions:", jsonMockResp);

            setMockInterviewQuestion(jsonMockResp);
            setInterviewData(result[0]);

        } catch (err) {
            console.log("DB Fetch Error:", err);
        }
    }

    return (
        <div className='p-5'>

            <div className='grid grid-cols-1 md:grid-cols-2 gap-10'>

                {/* Questions */}
                <QuestionSection
                    mockInterviewQuestion={mockInterviewQuestion}
                    activeQuestionIndex={activeQuestionIndex}
                />

                {/* Recording (client only) */}
                <RecordAnswerSection
                    mockInterviewQuestion={mockInterviewQuestion}
                    activeQuestionIndex={activeQuestionIndex}
                    interviewData={interviewData}
                />
            </div>

            {/* Navigation */}
            <div className='flex justify-end gap-6 mt-5'>

                {activeQuestionIndex > 0 && (
                    <Button onClick={() => setActiveQuestionIndex(prev => prev - 1)}>
                        Previous Question
                    </Button>
                )}

                {mockInterviewQuestion.length > 0 &&
                    activeQuestionIndex < mockInterviewQuestion.length - 1 && (
                        <Button onClick={() => setActiveQuestionIndex(prev => prev + 1)}>
                            Next Question
                        </Button>
                    )
                }

                {mockInterviewQuestion.length > 0 &&
                    activeQuestionIndex === mockInterviewQuestion.length - 1 && (
                        <Link href={`/dashboard/interview/${interviewData?.mockId}/feedback`}>
                            <Button>End Interview</Button>
                        </Link>
                    )
                }
            </div>

        </div>
    )
}

export default StartInterview;