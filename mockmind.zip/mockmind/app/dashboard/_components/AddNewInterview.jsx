"use client";
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { model } from '@/utils/GeminiAIModals'
import { LoaderCircle } from "lucide-react";
import { db } from "@/utils/db";
import { MockInterview } from "@/utils/schema";
import { v4 as uuidv4 } from "uuid";
import { useUser } from "@clerk/nextjs";
import moment from "moment";
import { useRouter } from "next/navigation";

function AddNewInterview() {
  const [openDialog, setOpenDialog] = useState(false);
  const [jobPosition, setJobPosition] = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [jobExp, setJobExp] = useState("");
  const [loading, setLoading] = useState(false);
  const [jsonResponse, setJsonResponse] = useState([]);

  const router = useRouter();
  const { user } = useUser();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const InputPrompt =
        "Job position:" +
        jobPosition +
        ", Job Description:" +
        jobDesc +
        ", Years of Experience:" +
        jobExp +
        ", Depends on Job Position, Job Description & Years of Experience give us " +
        process.env.NEXT_PUBLIC_INTERVIEW_QUESTION_COUNT +
        " Interview question along with Answer in JSON format, Give us question and answer field on JSON";

      // const result = await chatSession.sendMessage(InputPrompt)

      // const MockJsonResponse = (result.response.text())
      //   .replace(/```json/g, '')
      //   .replace(/```/g, '')
      //   .trim()

      const result = await model.generateContent(InputPrompt);

      const MockJsonResponse = result.response
        .text()
        .replace(/```json/g, "")
        .replace(/```/g, "")
        .trim();

      console.log(JSON.parse(MockJsonResponse));
      setJsonResponse(MockJsonResponse);

      if (MockJsonResponse) {
        const resp = await db
          .insert(MockInterview)
          .values({
            mockId: uuidv4(),
            jsonMockResp: MockJsonResponse,
            jobPosition: jobPosition,
            jobDesc: jobDesc,
            jobExperience: jobExp,
            createdBy: user?.primaryEmailAddress?.emailAddress,
            createdAt: moment().format("DD-MM-YYYY"),
          })
          .returning({ mockId: MockInterview.mockId });

        if (resp) {
          setOpenDialog(false);
          router.push("/dashboard/interview/" + resp[0]?.mockId);
        }
      } else {
        console.log("ERROR: No response");
      }
    } catch (err) {
      console.error("API ERROR:", err);
      alert("Something went wrong (API limit or error). Try again later.");
    }

    setLoading(false);
  };

  return (
    <div>
      {/* ADD BUTTON */}
      <div
        className="p-10 border rounded-lg bg-secondary hover:scale-105 hover:shadow-md cursor-pointer transition-all"
        onClick={() => setOpenDialog(true)}
      >
        <h2 className="text-lg text-center">+ Add New</h2>
      </div>

      {/* DIALOG */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              Tell us more about your job Interview
            </DialogTitle>

            {/* ✅ FIXED: ONLY TEXT HERE */}
            <DialogDescription>
              Add details about your job position, description and experience.
            </DialogDescription>
          </DialogHeader>

          {/* ✅ FORM MOVED OUTSIDE */}
          <form onSubmit={onSubmit}>
            <div>
              <h2 className="mt-4 font-semibold">
                Add details about your job position, job description and
                experience
              </h2>

              <div className="mt-7 my-3">
                <label>Job Position / Role</label>
                <Input
                  placeholder="Ex. Full Stack Developer"
                  required
                  onChange={(e) => setJobPosition(e.target.value)}
                />
              </div>

              <div className="my-3">
                <label>Job Description / Tech Stack</label>
                <Textarea
                  placeholder="Ex. React, Node, MySQL etc."
                  required
                  onChange={(e) => setJobDesc(e.target.value)}
                />
              </div>

              <div className="my-3">
                <label>Years of Experience</label>
                <Input
                  placeholder="Ex. 5"
                  type="number"
                  max="20"
                  required
                  onChange={(e) => setJobExp(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-5 justify-end mt-5">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setOpenDialog(false)}
              >
                Cancel
              </Button>

              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <LoaderCircle className="animate-spin mr-2" />
                    Generating from AI
                  </>
                ) : (
                  "Start Interview"
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default AddNewInterview;
