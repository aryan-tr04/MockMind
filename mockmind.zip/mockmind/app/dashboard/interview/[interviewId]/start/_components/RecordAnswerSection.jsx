"use client"

import { Button } from '@/components/ui/button'
import Image from 'next/image'
import React, { useEffect, useRef, useState } from 'react'
import Webcam from 'react-webcam'
import useSpeechToText from 'react-hook-speech-to-text'
import { Mic, StopCircle } from 'lucide-react'
import { toast } from 'sonner'
import { UserAnswer } from '@/utils/schema'
import { useUser } from '@clerk/nextjs'
import { db } from '@/utils/db'
import moment from 'moment'
import { GoogleGenerativeAI } from "@google/generative-ai"

function RecordAnswerSection({ mockInterviewQuestion, activeQuestionIndex, interviewData }) {

    const [userAnswer, setUserAnswer] = useState("")
    const [loading, setLoading] = useState(false)
    const finalAnswerRef = useRef("")   // ✅ IMPORTANT FIX

    const { user } = useUser()

    // ✅ Gemini init
    const genAI = new GoogleGenerativeAI(process.env.NEXT_PUBLIC_GEMINI_API_KEY)
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash-lite" })

    const {
        isRecording,
        results,
        startSpeechToText,
        stopSpeechToText,
        setResults
    } = useSpeechToText({
        continuous: true,
        useLegacyResults: false
    })

    // ✅ Collect speech safely
    useEffect(() => {
        if (results.length > 0) {
            const fullText = results.map(r => r.transcript).join(" ")
            setUserAnswer(fullText)
            finalAnswerRef.current = fullText   // ✅ always latest
        }
    }, [results])

    const StartStopRecording = async () => {

        if (isRecording) {
            stopSpeechToText()

            // ✅ WAIT for final speech capture
            setTimeout(async () => {

                const finalAnswer = finalAnswerRef.current?.trim()

                console.log("FINAL ANSWER:", finalAnswer)

                if (!finalAnswer || finalAnswer.length < 5) {
                    toast("Please speak properly...")
                    return
                }

                await UpdateUserAnswer(finalAnswer)

            }, 2000)

        } else {
            setUserAnswer("")
            finalAnswerRef.current = ""
            setResults([])
            startSpeechToText()
        }
    }

    const UpdateUserAnswer = async (finalAnswer) => {

        try {
            setLoading(true)

            const currentQ = mockInterviewQuestion?.[activeQuestionIndex]

            console.log("Current Question:", currentQ)
            console.log("Interview Data:", interviewData)

            if (!currentQ) {
                toast("Question missing")
                return
            }

            const prompt = `
Question: ${currentQ.question}
User Answer: ${finalAnswer}

Respond ONLY in JSON:
{
  "rating": "number out of 10",
  "feedback": "short improvement feedback"
}
`

            // ✅ Retry logic
            let result
            let retries = 3

            while (retries > 0) {
                try {
                    result = await model.generateContent(prompt)
                    break
                } catch (err) {
                    console.log("Retrying API...", err)
                    if (retries === 1) throw err
                    await new Promise(res => setTimeout(res, 2000))
                    retries--
                }
            }

            let text = result?.response?.text() || ""

            console.log("RAW AI RESPONSE:", text)

            text = text.replace(/```json/g, '').replace(/```/g, '').trim()

            let parsed

            try {
                parsed = JSON.parse(text)
            } catch {
                console.log("JSON failed, fallback used")
                parsed = {
                    rating: "5",
                    feedback: "Basic answer. Try to be more structured."
                }
            }

            const mockId = interviewData?.mockId

            console.log("mockId:", mockId)

            if (!mockId) {
                toast("Interview ID missing ❌")
                return
            }

            console.log("Saving to DB...")

            await db.insert(UserAnswer).values({
                mockIdRef: mockId,
                question: currentQ.question,
                correctAns: currentQ.answer,
                userAns: finalAnswer,
                feedback: parsed.feedback,
                rating: parsed.rating,
                userEmail: user?.primaryEmailAddress?.emailAddress,
                createdAt: moment().format('DD-MM-YYYY')
            })

            console.log("Saved successfully!")

            toast("Answer saved successfully ✅")

            // reset
            setUserAnswer("")
            finalAnswerRef.current = ""
            setResults([])

        } catch (err) {
            console.log("ERROR:", err)
            toast("Failed to save answer (API busy)")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className='flex items-center justify-center flex-col'>

            <div className='flex flex-col mt-20 justify-center items-center bg-gray-800 rounded-lg p-5'>
                <Image src={'/cam.jpg'} width={200} height={200} alt='camera' className='absolute' />

                <Webcam
                    mirrored={true}
                    style={{
                        height: 300,
                        width: '100%',
                        zIndex: 10,
                    }}
                />
            </div>

            <Button
                disabled={loading}
                variant="outline"
                className='my-10'
                onClick={StartStopRecording}
            >
                {isRecording ? (
                    <h2 className='text-red-600 animate-pulse flex gap-2 items-center'>
                        <StopCircle /> Stop Recording
                    </h2>
                ) : (
                    <h2 className='text-primary flex gap-2 items-center'>
                        <Mic /> Record Answer
                    </h2>
                )}
            </Button>

        </div>
    )
}

export default RecordAnswerSection